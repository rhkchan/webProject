/**
 * LoginBean.java
 * 
 */

package com.tutorial;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.faces.event.ComponentSystemEvent;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;
@ManagedBean
@RequestScoped
public class LoginBean
{
    @ManagedProperty(value = "#{param.userID}")
    private String userID;
    private String name;
    private String password;
    private ArrayList<CandidateBean> candidateList = new ArrayList<CandidateBean>();

    public String getName () throws IOException
    {
        return name;
    }

    public void setName (final String name)
    {
        this.name = name;
    }

    public String getPassword ()
    {
        return password;
    }

    public void setPassword (final String password)
    {
        this.password = password;
    }
    
    public ArrayList<CandidateBean> getCandidateList() throws IOException {
    	if(candidateList.isEmpty())
    	{
    		this.candidateList = createCandidateList();
    	}
		return this.candidateList;
	}

	public void setCandidateList(ArrayList<CandidateBean> candidateList) {
		this.candidateList = candidateList;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public static final String JSON_FILE="candidatesSample.txt";
	
	private ArrayList<CandidateBean> createCandidateList()
    {
		InputStream fis = LoginBean.class.getResourceAsStream("/resources/candidatesSample.txt");
		JsonReader reader = null;
		try {
			reader = Json.createReader(fis);
		} catch (Exception e) {
			e.printStackTrace();
		}

		JsonObject jsonObject = reader.readObject();
		
		JsonArray jsonArray = (JsonArray) jsonObject.get("Candidates");
		ArrayList<CandidateBean> arrayList = new ArrayList<CandidateBean>();
		CandidateBean candidateBean = new CandidateBean();
		for (int i = 0; i < jsonArray.size(); i++) {
			JsonObject explrObject = jsonArray.getJsonObject(i);
			
			JsonValue jsonValueName = explrObject.get("Name");
			String nameStr = jsonValueName.toString();
			candidateBean.setName(nameStr);
			System.out.println(nameStr);
			
			JsonValue jsonValueDOB = explrObject.get("DOB");
			String dOBStr = jsonValueDOB.toString();
			candidateBean.setDateOfBirth(dOBStr);
			System.out.println(dOBStr);
			
			JsonValue jsonValueWorkExperience = explrObject.get("WorkExperience");
			String workExperienceStr = jsonValueWorkExperience.toString();
			candidateBean.setWorkExperience(workExperienceStr);
			System.out.println(workExperienceStr);
			
			candidateBean.setId(i);
			
			arrayList.add(candidateBean);
			candidateBean = new CandidateBean();
		}
		return arrayList;
    }
	
	
	public void load(ComponentSystemEvent componentSystemEvent) throws IOException {
		ArrayList<CandidateBean> arrayList = getCandidateList();
		
		for (Iterator<CandidateBean> iterator = arrayList.iterator(); iterator.hasNext();) {
			CandidateBean candidateBean = (CandidateBean) iterator.next();
			if(Integer.toString(candidateBean.getId()).equals(getUserID()))
			{
				setSubName(candidateBean.getName());
				setSubDOB(candidateBean.getDateOfBirth());
				setSubWorkExperience(candidateBean.getWorkExperience());
				break;
			}
		}
	}    
 
	
	public String getSubName() {
		return subName;
	}

	public void setSubName(String subName) {
		this.subName = subName;
	}

	public String getSubDOB() {
		return subDOB;
	}

	public void setSubDOB(String subDOB) {
		this.subDOB = subDOB;
	}

	public String getSubWorkExperience() {
		return subWorkExperience;
	}

	public void setSubWorkExperience(String subWorkExperience) {
		this.subWorkExperience = subWorkExperience;
	}

	private String subName;
	private String subDOB;
	private String subWorkExperience;
}
