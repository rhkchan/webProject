package com.tutorial;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.URL;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;


public class JSONReadFromFileTest {

	public static void main(String[] args) throws FileNotFoundException
	{
		URL url = Thread.currentThread().getContextClassLoader().getResource("resources/candidatesSample.txt");
		System.out.println(url.getPath());
				
		JsonReader reader = Json.createReader(new FileReader(url.getPath()));

		JsonObject jsonObject = reader.readObject();
		
		JsonArray jsonArray = (JsonArray) jsonObject.get("Candidates");
		
		for (int i = 0; i < jsonArray.size(); i++) {
			JsonObject explrObject = jsonArray.getJsonObject(i);
			JsonValue jsonValuename = explrObject.get("Name");
			String nameStr = jsonValuename.toString();
			System.out.println(nameStr);
			
			JsonValue jsonValueDOB = explrObject.get("DOB");
			String dOBStr = jsonValueDOB.toString();
			System.out.println(dOBStr);
			
			JsonValue jsonValueWorkExperience = explrObject.get("WorkExperience");
			String workExperienceStr = jsonValueWorkExperience.toString();
			System.out.println(workExperienceStr);
		}
	}
}
